# agarbot
These are easy to use smooth going bots on Agar.io
that are coming soon!
This script is almost done!
